﻿exports.app_key = "6fff1bd82a48999d23625e89cb069cb0"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置