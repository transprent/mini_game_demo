﻿exports.app_key = "e6672f2469fb8cc62948516c6cd97c99"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置