/**
 * 数据集合
 */
let COLLECT_NAME = {};
COLLECT_NAME.GAME_DATA = "gamedata";

module.exports = COLLECT_NAME;