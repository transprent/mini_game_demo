/**
 * 道具配置
 */
let TOOL_CFG = {
    CLEAR: 1,
    LEVEL_UP: 2,
    ROLL_BACK: 3
};
module.exports = TOOL_CFG;